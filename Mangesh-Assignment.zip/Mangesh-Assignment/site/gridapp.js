 var app = angular.module('gridapp', []);
        app.controller('forexRates', function($scope) {
            $scope.data = [];
            $scope.sparkRefs = [];

            /*This function update all charts , this is essential to update all chart as sorting also chart as due to sorting index changes for row*/
             $scope.updateChart = function(){
                var len = $scope.data.length;
                for(var i=0;i<len;i++){
                    var rec = $scope.data[i];
                    if(rec){      
                        var name = rec.name;              
                        var sparkElement = document.getElementById(name+"-sparkline");    
                        var sparkRef = new Sparkline(sparkElement);             
                        $scope.sparkRefs[i] = sparkRef;

                        var max = rec.chartData.reduce(function(a, b) {
                            return Math.max(a, b);
                        });
                        var min = rec.chartData.reduce(function(a, b) {
                            return Math.min(a, b);
                        });
                       
                        var len = rec.chartData.length;                       
                        for(var j = 0; j < len ; j++) {  
                            var diff = max-min;
                            if(diff !=0 && !isNaN(diff)){                               
                               rec.chartData[j] = rec.chartData[j]/(max-min)*100;  
                             }                      
                        }  
                        //console.log("rec.chartData == ",rec.chartData);
                        sparkRef.draw(rec.chartData);  
                    }
                }
             }
});