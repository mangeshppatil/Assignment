/**
 * This javascript file will constitute the entry point of your solution.
 *
 * Edit it as you need.  It currently contains things that you might find helpful to get started.
 */

// This is not really required, but means that changes to index.html will cause a reload.
//require('./site/index.html')
// Apply the styles in style.css to the page.
//require('./site/style.css')

// if you want to use es6, you can do something like
//     require('./es6/myEs6code')
// here to load the myEs6code.js file, and it will be automatically transpiled.

// Change this to get detailed logging from the stomp library
//global.DEBUG = false

const url = "ws://localhost:8011/stomp"
const client = Stomp.client(url)

var data=[];
var dataKey ='';
var gridScope = null;
function connectCallback() {
client.subscribe("/fx/prices", dataCallback);   
}

client.connect({}, connectCallback, function(error) {
  alert(error.headers.message);
})

/*
*  This is the function which will retrive the latest prices from STOMP.
*/
function dataCallback(forexRates) {
	 if (forexRates.body) {
      updateData(JSON.parse(forexRates.body))
    } else {
      alert("got empty message");
    }	
}


/*This function updates the data collection with new response and add or update the existing entry in collection*/

function updateData(obj){
  dataKey = obj.name;
  var index = data.findIndex(isExist);  
  var pt = 0;    
  var rec = data[index];
  if(index == -1 ){
     pt = (obj.lastChangeAsk+obj.lastChangeBid)/2;    
     obj.chartData = [pt];
     data.push(obj)
  }else{
     obj.chartData = rec.chartData;
     data[index] = obj;     
  }
  pt = (obj.openAsk+obj.openBid)/2;   

  if(rec && rec.chartData){
       if(rec.chartData.length ==30){
        rec.chartData.shift();
       }
       rec.chartData.push(pt);
       if(!gridScope){
        gridScope = angular.element(document.getElementById('grid')).scope();
       }else{
        gridScope.updateChart();
       }
  }
  
  if(gridScope){
    gridScope.data = data;
    if (gridScope.$root.$$phase != '$apply' && gridScope.$root.$$phase != '$digest') {
      gridScope.$apply();
    }
  }
 
}

/*To check is this currency already exist */

function isExist(obj) {
  return obj.name == dataKey;
}
